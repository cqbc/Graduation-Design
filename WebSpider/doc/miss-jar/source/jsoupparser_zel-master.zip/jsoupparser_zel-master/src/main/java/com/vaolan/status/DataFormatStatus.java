package com.vaolan.status;

/**
 * 对所要结果数据格式的枚举,现分为2种，纯文本和标签自身的全部内容,默认为纯文本
 * 
 * @author zel
 * 
 */
public enum DataFormatStatus {
	CleanTxt, TagAllContent
}
