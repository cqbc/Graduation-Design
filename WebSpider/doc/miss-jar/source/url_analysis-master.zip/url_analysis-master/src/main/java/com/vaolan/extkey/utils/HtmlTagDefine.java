package com.vaolan.extkey.utils;

/**
 * html标签的标签定义
 * 
 * @author zel
 * 
 */
public class HtmlTagDefine {
	public static String A_Href = "href";
	public static String Link_Sign_And = "&amp;";
	public static String Http_Prefix = "http:";
	public static String Title = "title";

}
